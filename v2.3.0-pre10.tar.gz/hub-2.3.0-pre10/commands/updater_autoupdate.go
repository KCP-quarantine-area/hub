// +build autoupdate

package commands

func init() {
	EnableAutoUpdate = true
}
