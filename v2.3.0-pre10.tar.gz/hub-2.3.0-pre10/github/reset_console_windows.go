// +build  windows
package commands

// This does nothing on windows
func setConsole(cmd *cmd.Cmd) {
}
